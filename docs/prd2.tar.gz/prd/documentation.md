# 草果地图 — 技术文档站 PRD

| 项目 | 说明 |
|------|------|
| **产品名称** | 草果地图 · 技术文档站 |
| **文档版本** | V1.0 |
| **编写日期** | 2026-08-21 |
| **域名** | map.hb.cn/docs |
| **目标读者** | 前端工程师、后端工程师、GIS 工程师、运维工程师 |

---

## 一、目标

1. 开发者可在 10 分钟内跑通第一个地图应用
2. 所有 API 有代码示例，减少技术支持工单
3. G 端/央国企运维团队可自行完成私有化部署
4. 文档本身就是产品体验的一部分

---

## 二、信息架构

```
docs/
├── index.md                  # 首页（快速开始引导）
│
├── guide/                    # 入门指南
│   ├── quickstart.md         # 5 分钟快速开始
│   ├── installation.md       # 安装方式汇总
│   ├── first-map.md          # 第一个地图应用
│   ├── concepts/             # 核心概念
│   │   ├── coordinates.md    # 坐标系说明（CGCS2000/GCJ-02/WGS84）
│   │   ├── style.md          # 样式系统
│   │   ├── layers.md         # 图层类型
│   │   ├── sources.md        # 数据源管理
│   │   └── projection.md     # 投影与转换
│   └── guides/               # 实用教程
│       ├── offline.md        # 离线部署指南
│       ├── custom-style.md   # 自定义样式
│       ├── data-import.md    # 数据导入指南
│       └── performance.md    # 性能调优
│
├── api/                      # API 参考
│   ├── map.md                # Map 核心类
│   ├── layer/                # 图层 API
│   │   ├── circle.md         # Circle 图层
│   │   ├── line.md           # Line 图层
│   │   ├── fill.md           # Fill 图层
│   │   ├── symbol.md         # Symbol 图层
│   │   ├── heatmap.md        # Heatmap 图层
│   │   └── raster.md         # Raster 图层
│   ├── source/               # 数据源 API
│   │   ├── geojson.md        # GeoJSON 数据源
│   │   ├── vector.md         # 矢量切片数据源
│   │   ├── raster.md         # 栅格瓦片数据源
│   │   └── wmts.md           # WMTS 数据源
│   ├── control/              # 控件 API
│   │   ├── navigation.md     # 导航控件
│   │   ├── scale.md          # 比例尺
│   │   └── popup.md          # 弹窗
│   ├── event.md              # 事件系统
│   ├── camera.md             # 相机控制
│   └── geo/                  # 地理工具
│       ├── buffer.md         # 缓冲区分析
│       ├── intersect.md      # 相交分析
│       └── distance.md       # 距离计算
│
├── ai/                       # AI 能力
│   ├── copilot.md            # MapCopilot 使用指南
│   ├── nlpg.md               # NLPG 自然语言查询
│   ├── geoai.md              # GeoAI 数据入图
│   └── debug.md              # AI Debug 工具
│
├── industry/                 # 行业方案
│   ├── pipeline/             # 地下管网
│   │   ├── overview.md       # 方案概览
│   │   ├── topology.md       # 拓扑编辑器
│   │   ├── burst.md          # 爆管推演
│   │   ├── leakage.md        # 泄漏扩散
│   │   ├── health.md         # 健康评估
│   │   └── data-spec.md      # 数据接入规范
│   ├── grid/                 # 电网
│   │   ├── overview.md
│   │   ├── topology.md       # 电网拓扑
│   │   ├── outage.md         # 停电分析
│   │   ├── load.md           # 负荷热力图
│   │   └── data-spec.md
│   ├── water/                # 水网
│   │   ├── overview.md
│   │   ├── river.md          # 水系拓扑
│   │   ├── flood.md          # 洪水淹没
│   │   ├── dam.md            # 水库调度
│   │   └── data-spec.md
│   ├── transport/            # 交通网
│   │   ├── overview.md
│   │   ├── road.md           # 路网编辑器
│   │   ├── traffic.md        # 交通流量
│   │   ├── incident.md       # 事件响应
│   │   └── data-spec.md
│   ├── compute/              # 算力网
│   │   ├── overview.md
│   │   ├── nodes.md          # 算力节点
│   │   ├── fiber.md          # 光缆路由
│   │   └── data-spec.md
│   └── telecom/              # 通信网
│       ├── overview.md
│       ├── coverage.md       # 基站覆盖
│       ├── health.md         # 网络健康
│       └── data-spec.md
│
├── deployment/               # 部署运维
│   ├── docker.md             # Docker 部署
│   ├── k8s.md                # Kubernetes 部署
│   ├── air-gap.md            # 离线/内网部署
│   ├── nginx.md              # Nginx 配置
│   ├── tiles.md              # 瓦片服务配置
│   └── monitoring.md         # 监控与告警
│
├── examples/                 # 代码示例
│   ├── basic-map.md          # 基础地图
│   ├── custom-marker.md      # 自定义标记
│   ├── heatmap.md            # 热力图
│   ├── vector-tiles.md       # 矢量切片
│   ├── geojson-layer.md      # GeoJSON 图层
│   ├── popup-info.md         # 信息弹窗
│   └── 3d-terrain.md         # 3D 地形
│
├── faq/                      # 常见问题
│   ├── coordinates.md        # 坐标偏移问题
│   ├── tiles-slow.md         # 瓦片加载慢
│   ├── style-custom.md       # 样式定制
│   ├── offline.md            # 离线问题
│   └── compatibility.md      # 浏览器兼容性
│
└── contributing/             # 贡献指南（开源）
    ├── guide.md              # 如何贡献
    ├── architecture.md       # 项目架构
    └── code-style.md         # 代码规范
```

---

## 三、文档优先级

### P0 — 必须在 Phase 0 完成

| 文档 | 为什么是 P0 |
|------|------------|
| `guide/quickstart.md` | 开发者第一篇读的文档，决定是否继续 |
| `guide/installation.md` | 四种安装方式（npm/CDN/Docker/离线） |
| `guide/first-map.md` | 第一个地图应用教程 |
| `api/map.md` | Map 核心类 API 参考 |
| `api/layer/*.md` | 图层 API（最常用的 6 种） |
| `api/source/*.md` | 数据源 API |
| `deployment/docker.md` | G 端客户最关心的部署方式 |
| `deployment/air-gap.md` | 离线/内网部署（G 端刚需） |

### P1 — Phase 1 完成

| 文档 | 说明 |
|------|------|
| `ai/copilot.md` | MapCopilot 使用指南 |
| `ai/nlpg.md` | NLPG 查询接口文档 |
| `ai/geoai.md` | 数据入图管线文档 |
| `industry/pipeline/*.md` | 管网行业方案全套 |
| `guide/concepts/*.md` | 核心概念文档 |
| `examples/*.md` | 代码示例（至少 5 个） |
| `faq/*.md` | 常见问题（至少 5 篇） |

### P2 — Phase 2-3 完成

| 文档 | 说明 |
|------|------|
| `industry/grid/*.md` | 电网方案 |
| `industry/water/*.md` | 水网方案 |
| `industry/transport/*.md` | 交通方案 |
| `industry/compute/*.md` | 算力方案 |
| `industry/telecom/*.md` | 通信方案 |
| `deployment/k8s.md` | K8s 部署 |
| `contributing/*.md` | 贡献指南 |

---

## 四、文档模板

### 4.1 快速开始模板

```markdown
---
title: 5 分钟快速开始
---

# 5 分钟快速开始

本指南将帮助你在 5 分钟内创建第一个草果地图应用。

## 前提条件

- Node.js 18+
- 一个 HTML 文件

## 步骤 1：安装

::: code-group
​```bash [npm]
npm install @caoguo/maplibre
​```

​```html [CDN]
<script src="https://map.hb.cn/maplibre.js"></script>
​```
:::

## 步骤 2：创建地图

​```html
<!DOCTYPE html>
<html>
<head>
  <style>
    #map { width: 100%; height: 100vh; }
  </style>
</head>
<body>
  <div id="map"></div>
  <script>
    const map = new CaoguoMap.Map({
      container: 'map',
      center: [114.3, 30.5],
      zoom: 12,
      style: 'caoguo-dark'
    });
  </script>
</body>
</html>
​```

## 步骤 3：运行

​```bash
npx vite .
​```

打开浏览器访问 `http://localhost:5173`，你应该看到一个武汉地图。

## 下一步

- [核心概念](/guide/concepts/coordinates) — 了解坐标系
- [API 参考](/api/map) — 查看完整 API
- [行业方案](/industry/pipeline/overview) — 看看管网方案
```

### 4.2 API 参考模板

```markdown
---
title: Map 类
---

# Map

地图的核心类，负责初始化和管理地图实例。

## 构造函数

​```javascript
new CaoguoMap.Map(options: MapOptions)
​```

### MapOptions

| 参数 | 类型 | 默认值 | 描述 |
|------|------|--------|------|
| `container` | `string \| HTMLElement` | — | 地图容器 |
| `center` | `[number, number]` | `[0, 0]` | 初始中心点 [lng, lat] |
| `zoom` | `number` | `1` | 初始缩放级别 |
| `style` | `string \| object` | `'caoguo-light'` | 地图样式 |
| `pitch` | `number` | `0` | 地图倾斜角度 |
| `bearing` | `number` | `0` | 地图旋转角度 |

## 方法

### `addLayer(layer)`

添加图层到地图。

​```javascript
map.addLayer({
  id: 'my-layer',
  type: 'circle',
  source: 'my-source',
  paint: {
    'circle-radius': 6,
    'circle-color': '#ff6b35'
  }
});
​```

### `removeLayer(id)`

从地图中移除图层。

​```javascript
map.removeLayer('my-source');
​```

### `on(event, layerId, callback)`

监听地图事件。

​```javascript
map.on('click', 'my-layer', (e) => {
  console.log(e.features[0].properties);
});
​```
```

---

## 五、文档站技术方案

| 层 | 选择 | 说明 |
|----|------|------|
| 框架 | VitePress | 与落地页共享 |
| 搜索 | VitePress 内置（本地索引） | 中文支持 |
| 代码高亮 | Shiki（VitePress 内置） | 支持 JS/Python/SQL/Bash |
| 代码组 | VitePress `::: code-group` | 多种安装方式对比 |
| 自定义组件 | Vue 3 组件 | 可嵌入交互式地图 Demo |

### 交互式 Demo 嵌入

在文档中嵌入可交互的地图 Demo：

```vue
<!-- components/MapDemo.vue -->
<template>
  <div class="demo-container">
    <div ref="mapEl" class="map"></div>
    <div class="code-panel">
      <slot />
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import { Map } from '@caoguo/maplibre';

const mapEl = ref(null);

onMounted(() => {
  new Map({
    container: mapEl.value,
    center: [114.3, 30.5],
    zoom: 12,
    style: 'caoguo-dark'
  });
});
</script>
```

---

## 六、验收标准

| # | 标准 | 验收方式 |
|---|------|---------|
| 1 | 快速开始文档可在 10 分钟内跑通 | 新人盲测 |
| 2 | 所有 API 有代码示例 | 人工审查 |
| 3 | 部署文档覆盖 Docker/K8s/离线 | 运维团队按文档部署成功 |
| 4 | 搜索功能可用 | 关键词搜索命中 |
| 5 | 文档站与落地页视觉风格一致 | 目视检查 |
| 6 | 移动端可阅读 | 768px 以下测试 |
| 7 | 文档站 LCP < 1.5 秒 | Lighthouse 测试 |
| 8 | 无死链 | 爬虫检查 |

---

## 七、里程碑

| 天 | 任务 |
|----|------|
| D1-D2 | VitePress 搭建 + P0 文档框架 |
| D3-D5 | P0 文档内容撰写（快速开始 + API + 部署） |
| D6-D7 | 交互式 Demo 组件开发 |
| D8-D9 | P0 文档完善 + 搜索配置 |
| D10 | 测试 + 上线 |

---

> **文档的质量就是产品的质量。G 端客户的技术选型，往往在读完文档的那一刻就决定了。**
